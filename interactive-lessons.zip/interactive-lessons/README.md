# 🎓 Interactive Lessons Hub

A collection of gamified, interactive lessons for GCSE & IGCSE students.

## 📁 Structure

```
interactive-lessons/
├── index.html              # Main lesson menu
├── geography/
│   └── tectonic-hazards/   # Disaster Consultant Training
├── history/
│   └── (coming soon)
├── english/
│   └── (coming soon)
└── shared/
    ├── css/
    └── js/
```

## 🚀 Deployment

Connected to Netlify for automatic deployment.
Push to `main` branch → site updates automatically.

## ✨ Features

- 🎮 Gamification (XP, ranks, achievements)
- 📺 Embedded videos
- 🧠 Interactive quizzes
- 📤 Email submission to teacher
- 💾 Auto-save progress
- 📱 Mobile responsive

## 📝 Adding New Lessons

1. Create folder: `subject/lesson-name/`
2. Add `index.html` with lesson content
3. Update main `index.html` with link
4. Commit and push!
